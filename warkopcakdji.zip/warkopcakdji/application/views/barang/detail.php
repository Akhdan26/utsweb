<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Data Barang
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $barang['nama_barang']; ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted">Jumlah : <?= $barang['jumlah']; ?></h6>
                    <h6 class="card-subtitle mb-2 text-muted">Expired : <?= $barang['expired']; ?></h6>
                    <a href="<?= base_url(); ?>barang" class="btn btn-primary">Go Back</a>
                </div>
            </div>
        </div>
    </div>
</div>