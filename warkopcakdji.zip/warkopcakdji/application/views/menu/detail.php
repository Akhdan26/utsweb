<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Data Menu
                </div>
                <div class="card-body">
                    <h5 class="card-title"><?= $menu['nama']; ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?= $menu['jenis_menu']; ?></h6>
                    <h6 class="card-subtitle mb-2 text-muted"><?= $menu['harga']; ?></h6>
                    <a href="<?= base_url(); ?>menu" class="btn btn-primary">Go Back</a>
                </div>
            </div>
        </div>
    </div>
</div>