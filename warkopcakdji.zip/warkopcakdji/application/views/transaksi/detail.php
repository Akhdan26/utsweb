<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    Detail Data Transaksi
                </div>
                <div class="card-body">
                    <h5 class="card-title">Pegawai : <?= $transaksi['nama']; ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted">Nama Menu : <?= $transaksi['nama_menu']; ?></h6>
                    <h6 class="card-subtitle mb-2 text-muted">Harga Menu : <?= $transaksi['harga']; ?></h6>
                    <h6 class="card-subtitle mb-2 text-muted">Tanggal : <?= $transaksi['tanggal']; ?></h6>
                    <a href="<?= base_url(); ?>transaksi" class="btn btn-primary">Go Back</a>
                </div>
            </div>
        </div>
    </div>
</div>