<div class="container">
    <div class="row mt-3">
        <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                Form Tambah Data Transaksi
            </div>
            <div class="card-body">
            <?php if( validation_errors() ) : ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong><?= validation_errors(); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
            <?php endif; ?>
                <form action="" method="post">
                <div class="form-group">
                    <label for="id_karyawan">Nama Karyawan</label>
                    <input type="text" name="id_karyawan" class="form-control" id="id_karyawan">
                </div>
                <div class="form-group">
                    <label for="id_menu">Nama Menu</label>
                    <input type="text" name="id_menu" class="form-control" id="id_menu">
                </div>
                <div class="form-group">
                    <label for="tanggal">Tanggal</label>
                    <input type="text" name="tanggal" class="form-control" id="tanggal">
                </div>
                <button type="submit" name="tambah" class="btn btn-primary float-right">Tambah Data</button>
                </form>
            </div>
        </div>
        </div>
    </div>
</div>