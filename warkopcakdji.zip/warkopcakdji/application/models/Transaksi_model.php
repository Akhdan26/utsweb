<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi_model extends CI_Model {

    public function getAllTransaksi()
    {
        return $query = $this->db->get('transaksi')->result_array();
    }

    public function tambahDataTransaksi()
    {
        $data = [
            "nama_karyawan" => $this->input->post('nama_karyawan', true),
            "nama_menu" => $this->input->post('nama_menu', true),
            "tanggal" => $this->input->post('tanggal', true)
        ];

        $this->db->insert('transaksi', $data);
    }

    public function hapusDataTransaksi($id)
    {
        $this->db->where('id_transaksi', $id);
        $this->db->delete('transaksi');
    }

    public function getTransaksiById($id)
    {   
        $this->db->select("*");
        // $this->db->from("transaksi");
        $this->db->join("menu ","transaksi.id_menu=menu.id_menu");
        $this->db->join("karyawan ","transaksi.id_karyawan=karyawan.id_karyawan");
        return $this->db->get_where('transaksi', ['id_transaksi' => $id])->row_array();   
    }

    public function ubahDataTransaksi()
    {
        $data = [
            "nama_karyawan" => $this->input->post('nama_karyawan', true),
            "nama_menu" => $this->input->post('nama_menu', true),
            "tanggal" => $this->input->post('tanggal', true)
        ];

        $this->db->where('id_transaksi', $this->input->post('id_transaksi'));
        $this->db->update('transaksi', $data);
    }

    public function cariDataTransaksi()
    {
        $cari = $this->input->post('cari', true);
        $this->db->like('id_karyawan', $cari);
        $this->db->or_like('id_menu', $cari);
        $this->db->or_like('tanggal', $cari);
        return $this->db->get('transaksi')->result_array();
    }
}

/* End of file ModelName.php */

?>