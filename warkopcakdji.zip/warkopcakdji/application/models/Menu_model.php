<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Menu_model extends CI_Model {

    public function getAllMenu()
    {
        return $query = $this->db->get('menu')->result_array();
    }

    public function tambahDataMenu()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "harga" => $this->input->post('harga', true)
        ];

        $this->db->insert('menu', $data);
    }

    public function hapusDataMenu($id)
    {
        $this->db->where('id_menu', $id);
        $this->db->delete('menu');
    }

    public function getMenuById($id)
    {
        return $this->db->get_where('menu', ['id_menu' => $id])->row_array();   
    }

    public function ubahDataMenu()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "harga" => $this->input->post('harga', true)
        ];

        $this->db->where('id_menu', $this->input->post('id_menu'));
        $this->db->update('menu', $data);
    }

    public function cariDataMenu()
    {
        $cari = $this->input->post('cari', true);
        $this->db->like('nama', $cari);
        $this->db->or_like('harga', $cari);
        return $this->db->get('menu')->result_array();
    }
}

/* End of file ModelName.php */

?>