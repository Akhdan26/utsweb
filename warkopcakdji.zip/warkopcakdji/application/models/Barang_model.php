<?php
use GuzzleHttp\Client;

defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_model extends CI_Model {

    private $_client;

    public function __construct()
    {
        $this->_client = new Client([
            'base_uri' => 'http://localhost/cafe/api/',
            'auth' => ['akhdan','cafe123']
        ]);
    }

    public function getAllBarang()
    {
        // return $query = $this->db->get('Stock_barang')->result_array();
        
        $response = $this->_client->request('GET','barang',[
            'query' => [
                'cafe-key' => 'secret'
            ]
        ]);
        
        $result = json_decode($response->getBody()->getContents(), true);
        
        return $result['data'];
    }
    
    public function getBarangById($id)
    {
        // return $this->db->get_where('Stock_Barang', ['id' => $id])->row_array();   

        $response = $this->_client->request('GET','barang',[
            'query' => [
                'cafe-key' => 'secret',
                'id' => $id
            ]
        ]);
        
        $result = json_decode($response->getBody()->getContents(), true);
        
        return $result['data'][0];
    }

    public function tambahDataBarang()
    {
        $data = [
            "nama_barang" => $this->input->post('nama_barang', true),
            "jumlah" => $this->input->post('jumlah', true),
            "expired" => $this->input->post('expired', true),
            'cafe-key' => 'secret'
        ];

        // $this->db->insert('Stock_Barang', $data);
        
        $response = $this->_client->request('POST','barang',[
            'form_params' => $data
        ]);
        
        $result = json_decode($response->getBody()->getContents(), true);
        
        return $result;
    }

    public function hapusDataBarang($id)
    {
        // $this->db->where('id', $id);
        // $this->db->delete('Stock_Barang');
        
        $response = $this->_client->request('DELETE','barang',[
            'form_params' => [
                'cafe-key' => 'secret',
                'id' => $id
            ]
        ]);
        
        $result = json_decode($response->getBody()->getContents(), true);
        
        return $result;
    }

    public function ubahDataBarang()
    {
        $data = [
            "nama_barang" => $this->input->post('nama_barang', true),
            "jumlah" => $this->input->post('jumlah', true),
            "expired" => $this->input->post('expired', true),
            "id" => $this->input->post('id', true),
            'cafe-key' => 'secret'
        ];

        // $this->db->where('id', $this->input->post('id'));
        // $this->db->update('Stock_Barang', $data);
        
        $response = $this->_client->request('PUT','barang',[
            'form_params' => $data
        ]);
        
        $result = json_decode($response->getBody()->getContents(), true);
        
        return $result;
    }

    public function cariDataBarang()
    {
        $cari = $this->input->post('cari', true);
        $this->db->like('nama_barang', $cari);
        $this->db->or_like('jumlah', $cari);
        $this->db->or_like('expired', $cari);
        return $this->db->get('Stock_Barang')->result_array();
    }
}

/* End of file ModelName.php */

?>