<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Transaksi_model');
        $this->load->library('form_validation');
    }
    
    public function index()
    {

        $data['judul'] = 'Daftar Transaksi';
        $data['transaksi'] = $this->Transaksi_model->getAllTransaksi();
        if($this->input->post('cari')){
            $data['transaksi'] = $this->Transaksi_model->cariDataTransaksi();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('transaksi/index', $data);
        $this->load->view('templates/footer');
        
    }

    public function tambah()
    {
        $data['judul'] = 'Form Tambah Data Transaksi';
        $this->form_validation->set_rules('nama_karyawan', 'Nama_karyawan', 'required');
        $this->form_validation->set_rules('nama_menu', 'Nama_menu', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if( $this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('transaksi/tambah');
            $this->load->view('templates/footer');
        } else {
            $this->Transaksi_model->tambahDataTransaksi();
            $this->session->set_flashdata('flash','Ditambahkan');
            redirect('transaksi');
        }
    }

    public function hapus($id)
    {
        $this->Transaksi_model->hapusDataTransaksi($id);
        $this->session->set_flashdata('flash','Dihapus');
        redirect('transaksi');
    }

    public function detail($id)
    {
        $data['judul'] = 'Detail Data Transaksi';
        $data['transaksi'] = $this->Transaksi_model->getTransaksiById($id);

        $this->load->view('templates/header', $data);
        $this->load->view('transaksi/detail');
        $this->load->view('templates/footer');
    }

    public function ubah($id)
    {
        $data['judul'] = 'Form Ubah Data Transaksi';
        $data['transaksi'] = $this->Transaksi_model->getTransaksiByID($id);

        $this->form_validation->set_rules('id_karyawan', 'Id_karyawan', 'required');
        $this->form_validation->set_rules('id_menu', 'Id_menu', 'required');
        $this->form_validation->set_rules('tanggal', 'Tanggal', 'required');

        if( $this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('transaksi/ubah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Transaksi_model->ubahDataTransaksi();
            $this->session->set_flashdata('flash','Diubah');
            redirect('transaksi');
        }
    }
}

/* End of file Controllername.php */

?>