<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

$client = new Client();

$response = $client->request('GET','http://localhost/cafe/api/barang',[
    'query' => [
        'apikey' => ''
    ]
])

?>