<?php
defined('BASEPATH') or exit('No direct script access allowed');

class data extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }

    public function karyawan()
    {
        $data['judul'] = 'Daftar Karyawan';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $data['karyawan'] = $this->db->get('karyawan')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/header', $data);
        $this->load->view('data/karyawan', $data);
        $this->load->view('templates/footer');
    }

    public function tambahKaryawan()
    {
        $data['judul'] = 'Form Tambah Data Karyawan';
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/header', $data);
            $this->load->view('data/tambahKaryawan');
            $this->load->view('templates/footer');
        } else {
            $data = [
                'nama' => $this->input->post('nama'),
                'alamat' => $this->input->post('alamat'),
                'email' => $this->input->post('email')
            ];
            $this->db->insert('karyawan', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Karyawan added! </div>');
            redirect('data/karyawan');
        }
    }

    public function hapusKaryawan($id_karyawan)
    {
        $this->db->where('id_karyawan', $id_karyawan);
        $this->db->delete('karyawan');
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('data/karyawan');
    }

    public function ubahKaryawan($id_karyawan)
    {
        $data['judul'] = 'Form Ubah Data Karyawan';
        $data['karyawan'] = $this->db->get_where('karyawan', ['id_karyawan' => $id_karyawan])->row_array();
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/header', $data);
            $this->load->view('data/ubahKaryawan');
            $this->load->view('templates/footer');
        } else {
            $data = [
                'nama' => $this->input->post('nama', true),
                'alamat' => $this->input->post('alamat', true),
                'email' => $this->input->post('email', true)
            ];
            $this->db->where('id_karyawan', $id_karyawan);
            $this->db->update('karyawan', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Karyawan updated! </div>');
            redirect('data/karyawan');
        }
    }

    //menu
    public function menu()
    {
        $data['judul'] = 'Daftar Menu';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $data['makanan'] = $this->db->get('menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/header', $data);
        $this->load->view('data/menu', $data);
        $this->load->view('templates/footer');
    }
    public function tambahMenu()
    {
        $data['judul'] = 'Form Tambah Data Menu';
        $this->form_validation->set_rules('jenis_menu', 'Jenis_Menu', 'required');
        $this->form_validation->set_rules('nama_menu', 'Nama_Menu', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/header', $data);
            $this->load->view('data/tambahMenu');
            $this->load->view('templates/footer');
        } else {
            $data = [
                'jenis_menu' => $this->input->post('jenis_menu'),
                'nama_menu' => $this->input->post('nama_menu'),
                'harga' => $this->input->post('harga')
            ];
            $this->db->insert('menu', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New menu added! </div>');
            redirect('data/menu');
        }
    }

    public function hapusMenu($id_menu)
    {
        $this->db->where('id_menu', $id_menu);
        $this->db->delete('menu');
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('data/menu');
    }

    public function ubahMenu($id_menu)
    {
        $data['judul'] = 'Form Ubah Data Menu';
        $data['makanan'] = $this->db->get_where('menu', ['id_menu' => $id_menu])->row_array();
        $this->form_validation->set_rules('jenis_menu', 'Jenis_Menu', 'required');
        $this->form_validation->set_rules('nama_menu', 'Nama_Menu', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/header', $data);
            $this->load->view('data/ubahMenu', $data);
            $this->load->view('templates/footer');
        } else {
            $data = [
                'jenis_menu' => $this->input->post('jenis_menu', true),
                'nama_menu' => $this->input->post('nama_menu', true),
                'harga' => $this->input->post('harga', true)
            ];
            $this->db->where('id_menu', $id_menu);
            $this->db->update('menu', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Menu updated! </div>');
            redirect('data/menu');
        }
    }

    //barang
    public function stock_barang()
    {
        $data['judul'] = 'Daftar Stock Barang';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        $data['barang'] = $this->db->get('Stock_Barang')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/header', $data);
        $this->load->view('data/stock_barang', $data);
        $this->load->view('templates/footer');
    }

    public function tambahBarang()
    {
        $data['judul'] = 'Form Tambah Data Barang';
        $this->form_validation->set_rules('nama_barang', 'Nama_barang', 'required');
        $this->form_validation->set_rules('jumlah', 'Jumlah', 'required');
        $this->form_validation->set_rules('expired', 'Expired', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/header', $data);
            $this->load->view('data/tambahBarang');
            $this->load->view('templates/footer');
        } else {
            $data = [
                'nama_barang' => $this->input->post('nama_barang'),
                'jumlah' => $this->input->post('jumlah'),
                'expired' => $this->input->post('expired')
            ];
            $this->db->insert('Stock_barang', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New barang added! </div>');
            redirect('data/stock_barang');
        }
    }

    public function hapusBarang($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('Stock_Barang');
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('data/stock_barang');
    }

    public function ubahBarang($id)
    {
        $data['judul'] = 'Form Ubah Data Menu';
        $data['barang'] = $this->db->get_where('Stock_Barang', ['id' => $id])->row_array();
        $this->form_validation->set_rules('nama_barang', 'Nama_barang', 'required');
        $this->form_validation->set_rules('jumlah', 'Jumlah', 'required');
        $this->form_validation->set_rules('expired', 'Expired', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/header', $data);
            $this->load->view('data/ubahBarang', $data);
            $this->load->view('templates/footer');
        } else {
            $data = [
                'nama_barang' => $this->input->post('nama_barang', true),
                'jumlah' => $this->input->post('jumlah', true),
                'expired' => $this->input->post('expired', true)
            ];
            $this->db->where('id', $id);
            $this->db->update('Stock_Barang', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Barang updated! </div>');
            redirect('data/stock_barang');
        }
    }
}
