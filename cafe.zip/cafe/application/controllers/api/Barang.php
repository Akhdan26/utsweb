<?php

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Barang extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Barang_model', 'barang');

        $this->methods['index_get']['limit'] = 100;
    }

    public function index_get()
    {
        $id = $this->get('id');
        if ($id === null) {
            $barang = $this->barang->getBarang();
        } else {
            $barang = $this->barang->getBarang($id);
        }

        if ($barang) {
            $this->response([
                'status' => true,
                'data' => $barang
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'id not found'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id == null) {
            $this->response([
                'status' => false,
                'message' => 'provide an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            if ($this->barang->deleteBarang($id) > 0) {
                //ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'deleted.'
                ], REST_Controller::HTTP_OK);
            } else {
                //id not found
                $this->response([
                    'status' => false,
                    'message' => 'id not found!'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        }
    }

    public function index_post()
    {
        $data = [
            'nama_barang' => $this->post('nama_barang'),
            'jumlah' => $this->post('jumlah'),
            'expired' => $this->post('expired'),
        ];

        if ($this->barang->createBarang($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'new barang has been created'
            ], REST_Controller::HTTP_CREATED);
        } else {
            //id not found
            $this->response([
                'status' => false,
                'message' => 'failed to create new data!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function index_put()
    {
        $id = $this->put('id');
        $data = [
            'nama_barang' => $this->put('nama_barang'),
            'jumlah' => $this->put('jumlah'),
            'expired' => $this->put('expired'),
        ];

        if ($this->barang->updateBarang($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'data barang has been updated'
            ], REST_Controller::HTTP_OK);
        } else {
            //id not found
            $this->response([
                'status' => false,
                'message' => 'failed to update data!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}

/* End of file Controllername.php */
