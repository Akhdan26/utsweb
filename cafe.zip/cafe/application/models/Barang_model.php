<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Barang_model extends CI_Model
{

    public function getBarang($id = null)
    {
        if ($id === null) {
            return $this->db->get('Stock_Barang')->result_array();
        } else {
            return $this->db->get_where('Stock_Barang', ['id' => $id])->result_array();
        }
    }

    public function deleteBarang($id)
    {
        $this->db->delete('Stock_Barang', ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function createBarang($data)
    {
        $this->db->insert('Stock_Barang', $data);
        return $this->db->affected_rows();
    }

    public function updateBarang($data, $id)
    {
        $this->db->update('Stock_Barang', $data, ['id' => $id]);
        return $this->db->affected_rows();
    }
}

/* End of file ModelName.php */
