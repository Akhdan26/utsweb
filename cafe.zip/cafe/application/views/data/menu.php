<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
    <?php
    if ($_SESSION['user'] == 'admin') {
    ?>
        <div class="row mt-3">
            <div class="col-md-6">
                <a href="<?= base_url(); ?>data/tambahMenu" class="btn btn-primary mb-3">Tambah Data Menu</a>
            </div>
        </div>
    <?php } ?>
    <div class="row">
        <div class="col-lg-6">
            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?>

            <?= $this->session->flashdata('message'); ?>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Jenis Menu</th>
                        <th scope="col">Nama Menu</th>
                        <th scope="col">Harga</th>
                        <?php
                        if ($_SESSION['user'] == 'admin') {
                        ?>
                            <th scope="col">Action</th>
                        <?php } ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($makanan as $mk) : ?>
                        <tr>
                            <th scope="row"><?= $i ?></th>
                            <td><?= $mk['jenis_menu']; ?></td>
                            <td><?= $mk['nama_menu']; ?></td>
                            <td><?= $mk['harga']; ?></td>
                            <?php
                            if ($_SESSION['user'] == 'admin') {
                            ?>
                                <td>
                                    <a href="<?= base_url(); ?>data/ubahMenu/<?= $mk['id_menu']; ?>" class="badge badge-success">edit</a>
                                    <a href="<?= base_url(); ?>data/hapusMenu/<?= $mk['id_menu']; ?>" class="badge badge-danger">delete</a>
                                </td>
                            <?php } ?>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->